---secuencias---
CREATE SEQUENCE cliente_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE factura_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE orden_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE tipo_forma_pago_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE cliente_forma_pago_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


CREATE SEQUENCE cliente_direccion_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;
CREATE SEQUENCE producto_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE escala_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE empresa_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE paquete_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE producto_orden_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE historico_status_compra_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;

CREATE SEQUENCE status_compra_pk_seq
	INCREMENT 1
	MINVALUE 1
	NO CYCLE
	START 1;


--______ tablas____________---

CREATE TABLE cliente(
	cliente_id NUMERIC(10,0) DEFAULT nextval('cliente_pk_seq'),
	usuario VARCHAR(20) NOT NULL UNIQUE,
	passw VARCHAR(10) NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	ap_paterno VARCHAR(40) NOT NULL,
	ap_materno VARCHAR(40) NULL,
	telefono VARCHAR(10) NOT NULL,
	RFC VARCHAR(13) NULL,
	CONSTRAINT cliente_pk PRIMARY KEY (cliente_id)
);--Tabla creada sin error

CREATE TABLE cliente_direccion(
	direccion_id NUMERIC(10,0) DEFAULT nextval('cliente_direccion_pk_seq'),
	direccion VARCHAR(200) NOT NULL,
	cliente_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT direccion_pk PRIMARY KEY (direccion_id),
	CONSTRAINT cliente_fk FOREIGN KEY (cliente_id) 
		REFERENCES cliente(cliente_id)
);--tabla creada sin error

CREATE TABLE tipo_forma_pago(
	tipo_forma_pago_id  NUMERIC(10,0) NOT NULL DEFAULT nextval('tipo_forma_pago_pk_seq'),
	clave VARCHAR(20) NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	descripcion VARCHAR(100) NOT NULL,
	tipo  VARCHAR(1) NOT NULL CHECK (tipo='T' or tipo='B' or tipo='E'),
	CONSTRAINT tipo_forma_pago_pk PRIMARY KEY (tipo_forma_pago_id)
);-- tabla creada

CREATE TABLE cliente_forma_pago(
	cliente_forma_pago_id NUMERIC(10,0) DEFAULT nextval('cliente_forma_pago_pk_seq'),
	num_tarjeta VARCHAR(40) NULL,
	clabe VARCHAR(40) NULL,
	fecha_expriracion DATE NULL,-----cambiarrrrrr
	cliente_id NUMERIC(10,0) NOT NULL,
	tipo_forma_pago_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT cliente_forma_pago_pk PRIMARY KEY (cliente_forma_pago_id),
	CONSTRAINT cliente_fk FOREIGN KEY (cliente_id) 
		REFERENCES cliente(cliente_id),
	CONSTRAINT tipo_forma_pago_fk FOREIGN KEY (tipo_forma_pago_id) 
		REFERENCES tipo_forma_pago(tipo_forma_pago_id)
);--tabla creada

CREATE TABLE status_compra(
	status_compra_id NUMERIC(2,0) DEFAULT nextval('status_compra_pk_seq') ,
	clave VARCHAR(1) NOT NULL,
	descripcion VARCHAR(100) NOT NULL,
	activo VARCHAR(1) NOT NULL CHECK (activo = 'R' or activo = 'P' or activo = 'C'or activo= 'D'),
	CONSTRAINT status_compra_pk PRIMARY KEY (status_compra_id)
);--creado

CREATE TABLE orden(
	orden_id NUMERIC(10,0) DEFAULT nextval('orden_pk_seq'),
	fecha_status DATE NOT NULL,
	folio NUMERIC(10,0) NOT NULL,
	cliente_id NUMERIC(10,0) NOT NULL,
	status_compra_id NUMERIC(2,0) NOT NULL,
	CONSTRAINT orden_pk PRIMARY KEY (orden_id),
	CONSTRAINT cliente_fk FOREIGN KEY (cliente_id) 
		REFERENCES cliente(cliente_id),
	CONSTRAINT status_compra_fk FOREIGN KEY (status_compra_id) 
		REFERENCES status_compra(status_compra_id)
);--creado

CREATE TABLE historico_status_compra(
	historico_status_compra_id NUMERIC(10,0) DEFAULT nextval('historico_status_compra_pk_seq'),
	fecha_status DATE NOT NULL,
	status_compra_id NUMERIC(2,0) NOT NULL,
	orden_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT historico_status_compra_pk PRIMARY KEY (historico_status_compra_id),
	CONSTRAINT status_compra_fk FOREIGN KEY (status_compra_id) REFERENCES status_compra(status_compra_id),
	CONSTRAINT orden_fk FOREIGN KEY (orden_id) REFERENCES orden(orden_id)
);--creado

CREATE TABLE factura(
	factura_id NUMERIC(10,0) DEFAULT nextval('factura_pk_seq'),
	fecha_generacion DATE NOT NULL,
	total NUMERIC(18,2) NOT NULL,
	iva NUMERIC(18,2) NOT NULL,
	folio NUMERIC(10,0) NOT NULL,
	orden_id NUMERIC(10,0) NOT NULL,
	cliente_forma_pago_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT factura_pk PRIMARY KEY (factura_id),
	CONSTRAINT orden_fk FOREIGN KEY (orden_id) 
		REFERENCES orden(orden_id),
	CONSTRAINT cliente_forma_pago_fk FOREIGN KEY (cliente_forma_pago_id) 
		REFERENCES cliente_forma_pago(cliente_forma_pago_id)
);--creado

CREATE TABLE producto(
    producto_id NUMERIC(10,0) DEFAULT nextval('producto_pk_seq'),
    tipo         VARCHAR(1)      NOT NULL,
    folio        VARCHAR(13)     NOT NULL,
    precio_venta NUMERIC(8,2)    NOT NULL,
    es_fisico    NUMERIC(1,0)    NOT NULL,
    es_streaming NUMERIC(1,0)    NOT NULL,
    promocion_id NUMERIC(10,0)   NULL,
    CONSTRAINT producto_pk PRIMARY KEY (producto_id),
    CONSTRAINT promocion_fk FOREIGN KEY (promocion_id) 
    	REFERENCES producto(producto_id)
);--creado

CREATE TABLE empresa(
	empresa_id NUMERIC(10,0) DEFAULT nextval('empresa_pk_seq'),
	nombre VARCHAR(40) NOT NULL,
	clave VARCHAR(10) NOT NULL,
	zona_cobertura VARCHAR(1) NOT NULL CHECK (zona_cobertura='A' or zona_cobertura='B' or zona_cobertura='C'),
	CONSTRAINT empresa_pk PRIMARY KEY (empresa_id)
);--creado

CREATE TABLE paquete(
	paquete_id NUMERIC(10,0) DEFAULT nextval('paquete_pk_seq'),
	numero_seguimiento VARCHAR(24) NOT NULL,
	peso NUMERIC(8,4) NOT NULL,
	fecha_envio DATE NOT NULL,
	dimension VARCHAR(17) NOT NULL,
	factura_id NUMERIC(10,0) NOT NULL,
	empresa_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT paquete_pk PRIMARY KEY(paquete_id),
	CONSTRAINT factura_fk FOREIGN KEY (factura_id) 
		REFERENCES factura(factura_id),
	CONSTRAINT empresa_fk FOREIGN KEY (empresa_id) 
		REFERENCES empresa(empresa_id)
);--creado

CREATE TABLE producto_orden(
	producto_orden_id NUMERIC(10,0) DEFAULT nextval('producto_orden_pk_seq'),
	precio_unitario NUMERIC(10,2) NOT NULL,
	cantidad NUMERIC(10,0) NOT NULL,
	producto_id NUMERIC(10,0) NOT NULL,
	orden_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT producto_orden_pk PRIMARY KEY (producto_orden_id),
	CONSTRAINT producto_fk FOREIGN KEY (producto_id) 
		REFERENCES producto(producto_id),
	CONSTRAINT orden_fk FOREIGN KEY (orden_id) 
		REFERENCES orden(orden_id)
);--creado

CREATE TABLE streaming(
	URL VARCHAR(40)  NOT NULL,
	reproducciones NUMERIC(18,0) NOT NULL,
	producto_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT s_producto_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT streaming_pk PRIMARY KEY (producto_id)
);--creado

CREATE TABLE fisico(
	copias_vendidas NUMERIC(10,0) NOT NULL,
	copias_existencia NUMERIC(10,0) NOT NULL,
	copias_defectuosas NUMERIC(10,0) NOT NULL,
	producto_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT f_producto_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT fisico_pk PRIMARY KEY (producto_id)
);--creado

CREATE TABLE videojuego(
	nombre VARCHAR(40)  NOT NULL,
	descripcion VARCHAR(40) NOT NULL,
	tipo_consola VARCHAR(40) NOT NULL,
	producto_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT v_producto_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT videojuego_pk PRIMARY KEY (producto_id)
);--creado

CREATE TABLE album_musical(
	autor VARCHAR(40)  NOT NULL,
	nombre VARCHAR(40) NOT NULL,
	anio_creacion NUMERIC(4,0) NOT NULL,
	disquera VARCHAR(40) NOT NULL,
	producto_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT a_producto_producto_id_fk FOREIGN KEY (producto_id) REFERENCES producto(producto_id),
	CONSTRAINT album_pk PRIMARY KEY (producto_id)
);--creado

CREATE TABLE pelicula(
	nombre VARCHAR(40) NOT NULL,
	genero VARCHAR(40) NOT NULL,
	duracion numeric(4,0) NOT NULL,
	clasificacion VARCHAR(1) NOT NULL CHECK (clasificacion='A' or  clasificacion='B' or clasificacion='C'),
	formato_video VARCHAR(40) NOT NULL,
	producto_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT pelicula_pk PRIMARY KEY (producto_id),
	CONSTRAINT p_producto_producto_id_fk FOREIGN KEY (producto_id) 
		REFERENCES producto(producto_id)
);--creado

CREATE TABLE escala(
	numero_escala NUMERIC(3,0) DEFAULT nextval('escala_pk_seq'),
	lugar VARCHAR(100) NOT NULL,
	fecha_hora_arrivo DATE NOT NULL,
	paquete_id NUMERIC(10,0) NOT NULL,
	CONSTRAINT escala_pk PRIMARY KEY (numero_escala, paquete_id),
	CONSTRAINT paquete_fk FOREIGN KEY (paquete_id) 
		REFERENCES paquete(paquete_id)
);--creado