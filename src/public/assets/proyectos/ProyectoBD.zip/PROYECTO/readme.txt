Instrucciones
1.-Crear una base de datos
2.-Correr el script que dice TABLES.sql
3.-Correr el script que dice VALUES.sql
4.-Correr el script que dice JOIN.sql

DISFRUTAR