--insert para tabla cliente
INSERT INTO cliente (cliente_id, usuario, passw,nombre,ap_paterno, ap_materno,telefono)
	VALUES (nextval('cliente_pk_seq'), 'usuario01', '1q2w3e4r','Antonio','Figueroa','Martinez',257666756);

INSERT INTO cliente (cliente_id,usuario,passw,nombre,ap_paterno, ap_materno,telefono,RFC)
	VALUES (nextval ('cliente_pk_seq'),'usuario01','0o9i8u7y','Antoni','F.','R.','0984210523','VEC02034rw');

--cliente direccion

INSERT INTO  cliente_direccion (direccion_id, direccion,cliente_id)
	VALUES(nextval('cliente_direccion_pk_seq'),' alcaldia Alvaro Obregon #234, CDMX','7');

INSERT INTO  cliente_direccion (direccion_id, direccion,cliente_id)
	VALUES(nextval('cliente_direccion_pk_seq'),' colonia Roma #1021, CDMX','7');


--- Tabla status_compra
INSERT INTO status_COMPRA (status_compra_id, clave, descripcion,activo)
    VALUES (nextval('status_compra_pk_seq'),0,sin estado de compra,'D');
INSERT INTO status_COMPRA (status_compra_id, clave, descripcion,activo)
    VALUES (nextval('status_compra_pk_seq'),1,'estado de compra es: ',D);

--tabla factura
    INSERT INTO factura(factura_id, fecha_generacion,total,iva,folio,orden_id,cliente_forma_pago_id)	
     VALUES(nextval('factura_pk_seq'),to_date('04/02/2020','DD/MM/YYYY'),0.00,'123',1214,4,5);
INSERT INTO factura(factura_id, fecha_generacion,total,iva,folio,orden_id,cliente_forma_pago_id)	
     VALUES(nextval('factura_pk_seq'),to_date('05/02/2020','DD/MM/YYYY'),0.00,'123',1215,5,6);

--TABLA---------------empresa..............
INSERT INTO empresa(empresa_id,nombre,clave,zona_cobertura)
    VALUES (nextval('empresa_pk_seq'),'paqueteria 1','098','Z');

INSERT INTO empresa(empresa_id,nombre,clave,zona_cobertura)
    VALUES (nextval('empresa_pk_seq'),'paqueteria 5','099','CH');
