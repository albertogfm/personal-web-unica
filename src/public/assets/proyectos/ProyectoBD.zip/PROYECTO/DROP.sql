DROP.sql



DROP  cliente_pk_seq cascade ;
DROP TABLE factura CASCADE;
DROP TABLE producto_orden;
DROP TABLE orden CASCADE ;
DROP TABLE producto CASCADE;
DROP TABLE  cliente CASCADE;

--DROP DATABASE  proyectofinal;



