SELECT * FROM cliente;
SELECT * FROM status_compra;
SELECT * FROM paquete;
SELECT * FROM empresa;
SELECT * FROM producto_orden;
SELECT * FROM orden;
SELECT * FROM  historico_status_compra;
SELECT * FROM factura;
SELECT * FROM producto;
SELECT * FROM empresa;
SELECT * FROM paquete; 
SELECT * FROM producto_orden;
SELECT * FROM streaming;
SELECT * FROM  fisico;
SELECT * FROM videojuego;
SELECT * FROM album_musical;
SELECT * FROM pelicula;
SELECT * FROM escala;




--muestra  productos con  ambos tipos de adquisicion 
SELECT * FROM producto
where es_streaming =1 and es_fisico=1 ;

--solo clientes id mayores a 2
SELECT * FROM cliente_forma_pago
WHERE  cliente_id >2;




-------Modificacion de la tabla 
--tipo_forma_pago

UPDATE tipo_forma_pago set tipo='B'
WHERE tipo_forma_pago_id ='3';

UPDATE tipo_forma_pago set descripcion='usted podra pagar por Transferencia Bancaria'
where tipo_forma_pago_id ='3'
---tabla   cliente
--se cambia anula algun apellido materno

UPDATE cliente set ap_materno= null
WHERE cliente_id ='3';

------------JOINS-----------

--informacion sobre cliente

SELECT  * FROM cliente,cliente_direccion,cliente_forma_pago
WHERE cliente.cliente_id=cliente_direccion.cliente_id AND cliente.cliente_id = cliente_forma_pago.cliente_id;

--usuario-> factura
SELECT CL.usuario, ord.orden_id,FAC.factura_id,FAC.fecha_generacion FROM cliente CL, orden ord, factura FAC
WHERE CL.cliente_id = ord.cliente_id AND ord.orden_id = FAC.orden_id;

--peliculas-> precios

SELECT PELI.nombre as "Pelicula",PROD.precio_venta as "Precio"
FROM pelicula PELI JOIN producto PROD
ON PROD.producto_id = PELI.producto_id;
--videojuego->precios
SELECT VJ.nombre as "VideoJuego",PROD.precio_venta as "Precio"
FROM videojuego VJ JOIN producto PROD
ON PROD.producto_id = VJ.producto_id;

--album-Musical->precio

SELECT AM.nombre as "Album musical",PROD.precio_venta as "Precio"
FROM album_musical AM
JOIN producto PROD
ON PROD.producto_id = AM.producto_id;
--estado- Descripcion
SELECT orden.folio, SC.descripcion,SC.activo, CL.usuario
FROM orden 
LEFT JOIN status_compra SC
ON orden.status_compra_id = SC.status_compra_id
JOIN cliente CL
ON orden.cliente_id = CL.cliente_id;
--usuario. nombre, ap_paterno y direccion
SELECT CL.usuario ,CL.nombre ,CL.ap_paterno, CD.direccion 
FROM cliente CL RIGHT JOIN cliente_direccion CD
ON CL.cliente_id = CD.cliente_id;

-------Sub consultas
--fueron creadas con la finalidad de poder establecer un orden
--y seguimiento al momento de insertar los datos
--SELECT * FROM cliente;
--ALTER SEQUENCE cliente_pk_seq RESTART WITH 1;
--TRUNCATE TABLE cliente CASCADE  ;
--SELECT * FROM cliente_direccion;
--TRUNCATE TABLE cliente_direccion CASCADE  ;

--SELECT * FROM  tipo_forma_pago;
--TRUNCATE TABLE tipo_forma_pago CASCADE  ;
--ALTER SEQUENCE tipo_forma_pago_pk_seq RESTART WITH 1;


--SELECT * FROM cliente_forma_pago;
--TRUNCATE TABLE cliente_forma_pago CASCADE ;
--ALTER SEQUENCE cliente_forma_pago_pk_seq RESTART WITH 1;
