-----------------Cliente--------------------------

INSERT INTO cliente (cliente_id, usuario, passw,nombre,ap_paterno, ap_materno,telefono)
	VALUES (nextval('cliente_pk_seq'), 'usuario01', '1q2w3e4r','Antonio','Figueroa','Martinez','2397685141');

INSERT INTO cliente (cliente_id,usuario,passw,nombre,ap_paterno, ap_materno,telefono,RFC)
	VALUES (nextval ('cliente_pk_seq'),'usuario02','1q8u9i0o7y','Camila','Carmona','Torreon','0987847623','CA1946862776');

INSERT INTO cliente (cliente_id,usuario,passw,nombre,ap_paterno, ap_materno,telefono)
	VALUES (nextval('cliente_pk_seq'),'usuario03','2w6t5r34i','Dolores','Jimenez','Moreno','5543310342');

INSERT INTO cliente (cliente_id,usuario,passw,nombre,ap_paterno, ap_materno,telefono,RFC)
	VALUES (nextval ('cliente_pk_seq'),'usuario04','7y6t5r4e3','Armando','Piña','Luna','4098787662','EMc039422233');

INSERT INTO cliente (cliente_id,usuario,passw,nombre,ap_paterno, ap_materno,telefono,RFC)
	VALUES (nextval ('cliente_pk_seq'),'usuario05','0o9i8u7y','usuario_F','Bernal','Ruiz','0984210523','VEC02034rw');


 ---------------CLIENTE_DIRECCION-------
INSERT INTO  cliente_direccion (direccion_id, direccion,cliente_id)
	VALUES(nextval('cliente_direccion_pk_seq'),' colonia Roma #104, CDMX',1);

INSERT INTO  cliente_direccion (direccion_id, direccion,cliente_id)
	VALUES(nextval('cliente_direccion_pk_seq'),' alcaldia Coyoacan #234, CDMX',2);

INSERT INTO  cliente_direccion (direccion_id, direccion,cliente_id)
	VALUES(nextval('cliente_direccion_pk_seq'),' algaldia Alvaro Obregon #234, CDMX',3);

INSERT INTO  cliente_direccion (direccion_id, direccion,cliente_id)
	VALUES(nextval('cliente_direccion_pk_seq'),' colonia Roma #1021, CDMX',4);
	
INSERT INTO  cliente_direccion (direccion_id, direccion,cliente_id)
	VALUES(nextval('cliente_direccion_pk_seq'),' colonia Roma #234, CDMX',5 );
--ENTRA


--TABLA----------------------tipo_forma_pago-----------------------------------------
 INSERT INTO tipo_forma_pago(tipo_forma_pago_id,clave, nombre, descripcion, tipo)
 	VALUES (nextval('tipo_forma_pago_pk_seq'),'129584330493740','Efectivo','usted podra pagar con efectivo ...facil','E');

INSERT INTO tipo_forma_pago(tipo_forma_pago_id,clave, nombre, descripcion, tipo)
 	VALUES (nextval('tipo_forma_pago_pk_seq'),'1709504839944049','Efectivo','usted podra pagar con efectivo... facil','E');
--transferencia bancaria, se realiza  UPDATE debido a la forma de pago--ver Consultas
INSERT INTO tipo_forma_pago(tipo_forma_pago_id,clave, nombre, descripcion, tipo)
 	VALUES (nextval('tipo_forma_pago_pk_seq'),'9944048349709504','TRANSFERENCIA BANCARIA','usted podra pagar por T.B','B');

INSERT INTO tipo_forma_pago(tipo_forma_pago_id,clave, nombre, descripcion, tipo)
 	VALUES (nextval('tipo_forma_pago_pk_seq'),'539048004404709','TRANSFERENCIA BANCARIA','usted podra pagar por transferencia Bancaria...facil','B');

INSERT INTO tipo_forma_pago(tipo_forma_pago_id,clave, nombre, descripcion, tipo)
 	VALUES (nextval('tipo_forma_pago_pk_seq'),'049544803099479','TARJETA DE CREDITO','usted podra pagar con tarjeta de credito ...facil','T');

--ENTRA
--------------TABLA--cliente_forma_pago

INSERT INTO cliente_forma_pago(cliente_forma_pago_id,cliente_id,tipo_forma_pago_id )
	VALUES (nextval('cliente_forma_pago_pk_seq'),1,1);

INSERT INTO cliente_forma_pago(cliente_forma_pago_id,cliente_id,tipo_forma_pago_id )
	VALUES (nextval('cliente_forma_pago_pk_seq'),2,2);

INSERT INTO cliente_forma_pago(cliente_forma_pago_id,clabe,cliente_id,tipo_forma_pago_id)

	VALUES (nextval('cliente_forma_pago_pk_seq'),'018008483028557',3,3);

INSERT INTO cliente_forma_pago(cliente_forma_pago_id,clabe,cliente_id,tipo_forma_pago_id )
	VALUES (nextval('cliente_forma_pago_pk_seq'),'018008400028557',4,4);

INSERT INTO cliente_forma_pago(cliente_forma_pago_id,num_tarjeta,fecha_expriracion,cliente_id,tipo_forma_pago_id)
	VALUES (nextval('cliente_forma_pago_pk_seq'),'5673, 5251, 5091, 5262',to_date('12/40','MM/YY'),5,5);
--entra

--- Tabla status_compra
INSERT INTO status_COMPRA (status_compra_id, clave, descripcion,activo)
    VALUES (nextval('status_compra_pk_seq'),'0','estado de compra  R: ','R');
INSERT INTO status_COMPRA (status_compra_id, clave, descripcion,activo)
    VALUES (nextval('status_compra_pk_seq'),'1','estado de compra es: D','D');
INSERT INTO status_COMPRA (status_compra_id, clave, descripcion,activo)
    VALUES (nextval('status_compra_pk_seq'),'2','estado de compra es: D','P');
INSERT INTO status_COMPRA (status_compra_id, clave, descripcion,activo)
    VALUES (nextval('status_compra_pk_seq'),'3','estado de compra es: R ','R');
INSERT INTO status_COMPRA (status_compra_id, clave, descripcion,activo)
    VALUES (nextval('status_compra_pk_seq'),'4','estado de compra es: D ','D');


------Tabla orden
INSERT INTO  orden(orden_id,fecha_status,folio,cliente_id,status_compra_id)
    VALUES(nextval('orden_pk_seq'),to_date('01/02/2020','DD/MM/YYYY'),'1234',1,1);
INSERT INTO  orden(orden_id,fecha_status,folio,cliente_id,status_compra_id)
    VALUES(nextval('orden_pk_seq'),to_date('01/01/2020','DD/MM/YYYY'),'444',2,2);
    INSERT INTO  orden(orden_id,fecha_status,folio,cliente_id,status_compra_id)
    VALUES(nextval('orden_pk_seq'),to_date('14/02/2020','DD/MM/YYYY'),'3126',3,3);
    INSERT INTO  orden(orden_id,fecha_status,folio,cliente_id,status_compra_id)
    VALUES(nextval('orden_pk_seq'),to_date('02/01/2020','DD/MM/YYYY'),'7455',4,4);
    INSERT INTO  orden(orden_id,fecha_status,folio,cliente_id,status_compra_id)
    VALUES(nextval('orden_pk_seq'),to_date('05/02/2020','DD/MM/YYYY'),'7458',5,5);
--entra

--Tabla --- historico_status_compra
INSERT INTO historico_status_compra(historico_status_compra_id,fecha_status,status_compra_id,orden_id)
     VALUES(nextval('historico_status_compra_pk_seq'),to_date('02/02/2020','DD/MM/YYYY'),1,1);
INSERT INTO historico_status_compra(historico_status_compra_id,fecha_status,status_compra_id,orden_id)
     VALUES(nextval('historico_status_compra_pk_seq'),to_date('23/01/2020','DD/MM/YYYY'),2,2);
INSERT INTO historico_status_compra(historico_status_compra_id,fecha_status,status_compra_id,orden_id)
     VALUES(nextval('historico_status_compra_pk_seq'),to_date('29/02/2020','DD/MM/YYYY'),3,3);
INSERT INTO historico_status_compra(historico_status_compra_id,fecha_status,status_compra_id,orden_id)
     VALUES(nextval('historico_status_compra_pk_seq'),to_date('04/02/2020','DD/MM/YYYY'),4,4);
INSERT INTO historico_status_compra(historico_status_compra_id,fecha_status,status_compra_id,orden_id)
     VALUES(nextval('historico_status_compra_pk_seq'),to_date('10/02/2020','DD/MM/YYYY'),5,5);





--Tabla factura 
INSERT INTO factura(factura_id, fecha_generacion, total ,  iva  , folio ,orden_id ,  cliente_forma_pago_id)	
     VALUES(nextval('factura_pk_seq'),to_date('02/02/2020','DD/MM/YYYY'),520.20,16.0,0012,1,1);

INSERT INTO factura(factura_id, fecha_generacion,total,iva,folio,orden_id,cliente_forma_pago_id)	
     VALUES(nextval('factura_pk_seq'),to_date('23/01/2020','DD/MM/YYYY'),560.20,16.2,0121,2,2);
INSERT INTO factura(factura_id, fecha_generacion,total,iva,folio,orden_id,cliente_forma_pago_id)	
     VALUES(nextval('factura_pk_seq'),to_date('29/02/2020','DD/MM/YYYY'),540.20,16.8,1213,3,3);
INSERT INTO factura(factura_id, fecha_generacion,total,iva,folio,orden_id,cliente_forma_pago_id)	
     VALUES(nextval('factura_pk_seq'),to_date('04/02/2020','DD/MM/YYYY'),50,15.89,1214,4,4);
INSERT INTO factura(factura_id, fecha_generacion,total,iva,folio,orden_id,cliente_forma_pago_id)	
     VALUES(nextval('factura_pk_seq'),to_date('10/02/2020','DD/MM/YYYY'),200.3,16.03,1215,5,5);





--TABLA ----------producto---------
INSERT INTO  producto (producto_id, tipo, folio, precio_venta,es_fisico, es_streaming)
     VALUES(nextval('producto_pk_seq'),'1', '0012',12.50,0,1);

INSERT INTO  producto (producto_id, tipo, folio, precio_venta,es_fisico, es_streaming)
     VALUES(nextval('producto_pk_seq'),'1', '1234',45.02,1,1);

INSERT INTO  producto (producto_id, tipo, folio, precio_venta,es_fisico, es_streaming)
     VALUES(nextval('producto_pk_seq'),'2', '1235',125.30,1,0);

INSERT INTO  producto (producto_id, tipo, folio, precio_venta,es_fisico, es_streaming)
     VALUES(nextval('producto_pk_seq'),'1', '1236',12.50,1,1);

INSERT INTO  producto (producto_id, tipo, folio, precio_venta,es_fisico, es_streaming)
     VALUES(nextval('producto_pk_seq'),'3', '1237',60.50,0,1);
--creado


--TABLA---------------empresa..............
INSERT INTO empresa(empresa_id,nombre,clave,zona_cobertura)
    VALUES (nextval('empresa_pk_seq'),'paqueteria 1','098','A');

INSERT INTO empresa(empresa_id,nombre,clave,zona_cobertura)
    VALUES (nextval('empresa_pk_seq'),'paqueteria 5','099','B');

INSERT INTO empresa(empresa_id,nombre,clave,zona_cobertura)
    VALUES (nextval('empresa_pk_seq'),'paqueteria 2','102','A');

INSERT INTO empresa(empresa_id,nombre,clave,zona_cobertura)
    VALUES (nextval('empresa_pk_seq'),'paqueteria 7','241','C');

INSERT INTO empresa(empresa_id,nombre,clave,zona_cobertura)
    VALUES (nextval('empresa_pk_seq'),'paqueteria 3','172','C');



--TABLA---------paquete------------
INSERT INTO paquete(paquete_id,numero_seguimiento,peso,fecha_envio,dimension,factura_id,empresa_id)
    VALUES(nextval('paquete_pk_seq'),'09',123.60,to_date('02/2040','MM/YY'),'12x5x7 cm',1,1);
INSERT INTO paquete(paquete_id,numero_seguimiento,peso,fecha_envio,dimension,factura_id,empresa_id)
    VALUES(nextval('paquete_pk_seq'),'03',12.60,to_date('05/2020','MM/YY'),'5x6x4 cm',2,2);
INSERT INTO paquete(paquete_id,numero_seguimiento,peso,fecha_envio,dimension,factura_id,empresa_id)

    VALUES(nextval('paquete_pk_seq'),'04',556.2,to_date('04/2021','MM/YY'),'5x5x8 cm',3,3);
INSERT INTO paquete(paquete_id,numero_seguimiento,peso,fecha_envio,dimension,factura_id,empresa_id)
    VALUES(nextval('paquete_pk_seq'),'05',406.2,to_date('03/2022','MM/YY'),'9x9x6 cm',4,4);
INSERT INTO paquete(paquete_id,numero_seguimiento,peso,fecha_envio,dimension,factura_id,empresa_id)
    VALUES(nextval('paquete_pk_seq'),'06',478.60,to_date('06/2020','MM/YY'),'5x4x7 cm',5,5);



--TABLA--------producto_orden --------------------
INSERT INTO producto_orden(producto_orden_id,precio_unitario, cantidad,producto_id,orden_id)
    VALUES(nextval('producto_orden_pk_seq'),12.50,6,1,1);
INSERT INTO producto_orden(producto_orden_id,precio_unitario, cantidad,producto_id,orden_id)
    VALUES(nextval('producto_orden_pk_seq'),45.02,2,2,2);
INSERT INTO producto_orden(producto_orden_id,precio_unitario, cantidad,producto_id,orden_id)
    VALUES(nextval('producto_orden_pk_seq'),125.30,1,3,3);
INSERT INTO producto_orden(producto_orden_id,precio_unitario, cantidad,producto_id,orden_id)
    VALUES(nextval('producto_orden_pk_seq'),12.50,4,4,4);
INSERT INTO producto_orden(producto_orden_id,precio_unitario, cantidad,producto_id,orden_id)
    VALUES(nextval('producto_orden_pk_seq'),60.50,2,5,5);
	

--TABLA-----------streaming---------------------

INSERT INTO streaming(URL,reproducciones, producto_id)
    VALUES('WWW.cant_visualizaciones.com',2,1);
INSERT INTO streaming(URL,reproducciones, producto_id)
    VALUES('WWW.spotify.com',6,2);

INSERT INTO streaming(URL,reproducciones, producto_id)
    VALUES('WWW.applemusic.com',32,3);
INSERT INTO streaming(URL,reproducciones, producto_id)
    VALUES('WWW.soundcloud.com',1,4);
	
INSERT INTO streaming(URL,reproducciones, producto_id)
    VALUES('WWW.tidal.com',0,5);
--TABLA------------fisico---------------

INSERT INTO fisico(copias_vendidas,copias_existencia,copias_defectuosas,producto_id)
    VALUES(12,15005,0,1);
INSERT INTO fisico(copias_vendidas,copias_existencia,copias_defectuosas,producto_id)
    VALUES(13,154,1,2);
INSERT INTO fisico(copias_vendidas,copias_existencia,copias_defectuosas,producto_id)
    VALUES(0,34541,22,3);
INSERT INTO fisico(copias_vendidas,copias_existencia,copias_defectuosas,producto_id)
    VALUES(56,45454,2,4);
INSERT INTO fisico(copias_vendidas,copias_existencia,copias_defectuosas,producto_id)
    VALUES(283,4544,7,5);
	
	

--TABLA -------------videojuego-------------
INSERT INTO videojuego(nombre, descripcion,tipo_consola, producto_id)
    VALUES('Zoom','genero: aventura ','XBOX',1);

INSERT INTO videojuego(nombre, descripcion,tipo_consola, producto_id)
    VALUES('SlenderMan','genero: Terror','PsP4',2);
    
INSERT INTO videojuego(nombre, descripcion,tipo_consola, producto_id)
    VALUES('RockBand','genero:musical ','XBOX',3);

INSERT INTO videojuego(nombre, descripcion,tipo_consola, producto_id)
    VALUES('GTA','genero: aventura ','SWITCH',4);

INSERT INTO videojuego(nombre, descripcion,tipo_consola, producto_id)
    VALUES('SilentHill','genero: Terror','XBOX',5);
    
--TABLA -------------album_musical------
INSERT INTO album_musical(autor, nombre, anio_creacion, disquera, producto_id)
    VALUES('Bad Bunny','YHLQMDLG',2020,'Rimas Entretainment LLC',1);
INSERT INTO album_musical(autor, nombre, anio_creacion, disquera, producto_id)
    VALUES('Carla Morrison','Dejenme Llorar',2012,'Cosmica REcords',2);
INSERT INTO album_musical(autor, nombre, anio_creacion, disquera, producto_id)
    VALUES('Billie Eilish','dont smile at me',2017,'Interscope',3);
INSERT INTO album_musical(autor, nombre, anio_creacion, disquera, producto_id)
    VALUES('Galantis','Pharmacy',2015,'Atlantic Recording',4);
INSERT INTO album_musical(autor, nombre, anio_creacion, disquera, producto_id)
    VALUES('Lukas Graham','Lukas Graham',2016,'Warner',5);



--TABLA---------------pelicula------------
INSERT INTO pelicula(nombre,genero,duracion,clasificacion,formato_video,producto_id)
    VALUES('Son como niños','comedia',122,'A','mp4',1);

INSERT INTO pelicula(nombre,genero,duracion,clasificacion,formato_video,producto_id)
    VALUES('Harry Potter','Ficcion',129,'B','avi',2);
INSERT INTO pelicula(nombre,genero,duracion,clasificacion,formato_video,producto_id)
    VALUES('Narnia','Ficcion',112,'A','mp4',3);

INSERT INTO pelicula(nombre,genero,duracion,clasificacion,formato_video,producto_id)
    VALUES('Love Rosie','Amor',135,'C','avi',4);
INSERT INTO pelicula(nombre,genero,duracion,clasificacion,formato_video,producto_id)
    VALUES('Scooby Doo: El regreso','Accion',155,'A','mp4',5);

--TABLA----------------escala-----------------------

INSERT INTO escala(numero_escala, lugar, fecha_hora_arrivo, paquete_id)
VALUES(nextval('escala_pk_seq'),'Merida',to_date('12/02/2030','DD/MM/YY'),1);

INSERT INTO escala(numero_escala, lugar, fecha_hora_arrivo, paquete_id)
VALUES(nextval('escala_pk_seq'),'Cancun',to_date('22/02/2030','DD/MM/YY'),2);
INSERT INTO escala(numero_escala, lugar, fecha_hora_arrivo, paquete_id)
VALUES(nextval('escala_pk_seq'),'Oaxaca',to_date('24/06/2020','DD/MM/YY'),3);
INSERT INTO escala(numero_escala, lugar, fecha_hora_arrivo, paquete_id)
VALUES(nextval('escala_pk_seq'),'Puebla',to_date('1/02/2030','DD/MM/YY'),4);
INSERT INTO escala(numero_escala, lugar, fecha_hora_arrivo, paquete_id)
VALUES(nextval('escala_pk_seq'),'Zacatecas',to_date('12/02/2030','DD/MM/YY'),5);