# BlogFood

## Integrantes 
Alberto García Figueroa Munguía  
Jesús Bryan Parada Pérez   
Dani Boquer  
Beto Najera  
## Description 
Este proyecto es un pequeño blog food donde se tiene una página de inicio, la historia de la comida , unos platillos deliciosos y un formulario de registro.

## Como Usar
Bajar del repositorio el proyecto y abrir el index.html

## For download
HTTP:
```
git clone https://github.com/albertogfm/BlogFood.git
```
SSL:
```
git clone git@github.com:albertogfm/BlogFood.git
```


