import numpy as np
import matplotlib.pyplot as plt #Funciona para hacer las gráficas
import scipy.io.wavfile as waves
import scipy.fftpack as fourier #Se importa la transformada de Fourier
from scipy import fft, arange
import wave# Nos permite leer archivos .wav
import struct #Convierte cadenas a binario
import decimal #modifica el número de decimales de una variable de tipo float
import os #Nos permite operar el sistema

def editar_audio():
	file = input('Nombre del archivo de sonido ( sin el .wav):')
	archivoF = file + "Editado.wav"
	contenido, sonido = waves.read(file+".wav") #Lectura del archivo y de sus datos
	size = np.shape(sonido)
	muestras = size[0]
	m = len(size)
	canales = 1
	if (m>1):  #Frgmentación del archivo para poder analizarlos poster
	    canales = size[1]
	if (canales>1):
	    canal = 0
	    uncanal = sonido[:,canal]
	else:
	    uncanal = sonido

	start = 0.0 #Rango para cortar el audio
	end = 2.5

	a = int(start*contenido)
	b = int(end*contenido)

	audio_recortado = uncanal[a:b]
	print('Archivo Listo para analizar')
	print("Nombre del archivo: "+ archivoF)
	waves.write(archivoF, contenido, audio_recortado)
	os.system('pause')
	os.system('cls')

def identificadorDeNotas():
	#Valores por default para los parametros de las funciónes a continuación
	window_size = 2206    
	beta = 1
	max_notes = 100
	sampling_freq = 44100
	threshold = 600
	#Arreglos con las notas y sus Frecuencias
	array = [261.63, 293.66, 329.63, 349.23, 392.0, 440.00, 493.88,
	         523.25, 587.33, 659.26, 698.46, 783.99, 880.00, 987.77,
	         1046.50, 1174.66, 1318.51, 1396.91, 1567.98, 1760.00, 1975.53,
	         2093.00, 2349.32, 2637.02, 2793.83, 3135.96, 3520.00, 3951.07,
	         4186.01, 4698.63, 5274.04, 5587.65, 6271.93, 7040.00, 7902.13]

	notes = ['Do4', 'Re4', 'Mi4', 'Fa4', 'Sol4', 'La4', 'Si4',
	         'Do5', 'Re5', 'Mi5', 'Fa5', 'Sol5', 'La5', 'Si5',
	         'Do6', 'Re6', 'Mi6', 'Fa6', 'Sol6', 'La6', 'Si6',
	         'Do7', 'Re7', 'Mi7', 'Fa7', 'Sol7', 'La7', 'Si7',
	         'Do8', 'Re8', 'Mi8', 'Fa8', 'Sol8', 'La8', 'Si8']
	notasAnalizadas = []

	#Lectura de archivo y su extracción de datos
	file_name = input("Ingrese el nombre del archivo (sin el .wav): ")
	file_sound = wave.open(file_name+".wav", 'r')
	print ('\n\nEspere por favor...')

	file_length = file_sound.getnframes()


	sound = np.zeros(file_length)
	mean_square = []
	sound_square = np.zeros(file_length)

	#Desempaquetado de bytes a enteros
	for i in range(file_length):
	    infoSonido = file_sound.readframes(1)
	    #print(infoSonido)
	    infoSonido = struct.unpack("<h", infoSonido)
	    sound[i] = int(infoSonido[0])

	sound = np.divide(sound, float(2**15))	#División del sonido
	sound_square = np.square(sound)
	frequency = []
	dft = []
	i = 0
	j = 0
	k = 0
	# Partición de datos
	while(i<=len(sound_square)-window_size):
		s = 0.0
		j = 0
		while(j<=window_size):
			s = s + sound_square[i+j]
			j = j + 1
	# Detección de silencio
		if s < threshold:
			if(i-k>window_size*4):
				dft = np.array(dft)
				dft = np.fft.fft(sound[k:i])
				dft=np.argsort(dft)

				if(dft[0]>dft[-1] and dft[1]>dft[-1]):
					i_max = dft[-1]
				elif(dft[1]>dft[0] and dft[-1]>dft[0]):
					i_max = dft[0]
				else :
					i_max = dft[1]
	# Calculo de la frecuencia sin el silencio
				frequency.append((i_max*sampling_freq)/(i-k))
				dft = []
				k = i+1
		i = i + window_size
	print("El archivo se puede dividir en ",file_length," cuadros")
	print('Se dividio el audio en ',len(frequency), " partes para analizar su nota musical")
	print("| Frecuencia obtenida | Nota musical |")
	for i in frequency :
		idx = (np.abs(array-i)).argmin()
		notasAnalizadas.append(notes[idx])
		fre = round(i,2)
		print("|      ",fre,"          |       ",notes[idx],"       |")
	espectroAudio(file_name+".wav")
	indiceFrec = int(input("Ingrese el indice de la nota musicar el la lista a graficar"))

	graficas(len(frequency),frequency[indiceFrec])


def menu():
	x = True
	while(x):
		os.system('cls')
		print("Ingrese que desea hacer:")
		print("1.-Editar audio para poder analizarlo")
		print("2.-Analizar audio")
		print("3.-Salir")
		opt = int(input("->"))
		if(opt == 1):
			os.system('cls')
			editar_audio()
			os.system('cls')
		elif(opt == 2):
			os.system('cls')
			identificadorDeNotas()
			os.system('cls')
		elif(opt == 3):
			x = False
		else:
			print("Escoga una opción válida")

def espectroAudio(nombre):
	muestreo, sonido = waves.read(nombre)
	size = np.shape(sonido)
	muestras = size[0]
	m = len(size)
	canales = 1
	if (m>1):
	    canales = size[1]
	if (canales>1):
	    canal = 0
	    uncanal = sonido[:,canal]
	else:
	    uncanal = sonido

	inicia = 0.0
	termina = 2.5

	a = int(inicia*muestreo)
	b = int(termina*muestreo)
	audio_recortado = uncanal[a:b]

	#rango para graficar
	dt = 1/muestreo
	ta = a*dt
	tb = (b)*dt
	tab = np.arange(ta,tb,dt)

	plt.plot(tab,audio_recortado)
	plt.title("REPRESENTACIÓN AUDIO")
	plt.grid()
	plt.show()

def entradax(t,fs):
    x=np.cos(2*np.pi*fs*t)
    return(x)

def graficas(frames,fr):
	ventana = 0.4
	t0=0.0
	tn=0.4
	n= frames

	# PROCEDIMIENTO
	dt=(tn-t0)/n
	fs=fr
	t=np.arange(-tn,tn,dt)  # eje tiempo analógica
	m=len(t)
	xanalog=np.zeros(m, dtype=float)
	for i in range(0,m):
	    xanalog[i]=entradax(t[i],fs)

	# FFT: Transformada Rapida de Fourier

	xf=fourier.fft(xanalog[n:2*n])
	xf=fourier.fftshift(xf)
	# Rango de frecuencia para eje
	frq=fourier.fftfreq(n, dt)
	frq=fourier.fftshift(frq)

	# x[w] real
	xfreal=(1/n)*np.real(xf)
	# x[w] imaginario
	xfimag=(1/n)*np.imag(xf)
	# x[w] magnitud
	xfabs=(1/n)*np.abs(xf)
	# x[w] angulo
	xfangle=(1/n)*np.unwrap(np.angle(xf))

	#SALIDA
	plt.figure(1)       # define la grafica
	plt.suptitle('Transformada Rápida Fourier FFT')

	plt.subplot(211)    # grafica de 3x2, subgrafica 1
	plt.ylabel('xanalog[t]')
	plt.xlabel('tiempo')
	plt.plot(t,xanalog)
	plt.margins(0,0.05)
	plt.grid()


	ra=int(len(frq)*(0.5-ventana))
	rb=int(len(frq)*(0.5+ventana))


	plt.subplot(212)
	plt.ylabel('x[f] fase')
	plt.xlabel(' frecuencia (Hz)')
	plt.plot(frq[ra:rb],xfangle[ra:rb])
	plt.margins(0,0.05)
	plt.grid()

	plt.show() #Se muestra la gráfica

menu()
