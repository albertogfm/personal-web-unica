/**
	*Este programa es la clase video que es hija de Archivo
	*@author: Alberto Garcia
	*@version: 1.0
*/
package clases;
public class Video extends Archivo{
	private String productora, director;
	public Video(){
		super();
		this.productora = "N/A";
		this.director = "N/A";
	}
	public Video(String _nombre,String _autor, String _tiempo,int _anio,String _formato,String _productora,String _director){
		super(_nombre,_autor,_tiempo,_anio,_formato);
		this.productora =  _productora;
		this.director = _director;
	}

//Setters
	public void setProductora(String _productora){
		this.productora = _productora;
	}
	public void setDirector(String _director){
		this.director = _director;
	}
//GETTERS
	public String getProductora(){
		return this.productora;
		}
	public String getDirector(){
		return this.director;
		}

//Metodos
	public String toString(){
		return super.toString()+
			   "\n\tProductora: "+getProductora()+
			   "\n\tDirector: "+getDirector();
	}



}