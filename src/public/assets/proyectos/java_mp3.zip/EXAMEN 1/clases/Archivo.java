/**
	*Este clase define el objeto archivos
	*@author: Alberto Garcia
	*@version: 1.0
*/
package clases;
public class Archivo{
	private String nombre , autor, tiempo,  formato;
	private int anioEstreno;
	public Archivo(){
		this.nombre = "N/A";
		this.autor = "N/A";
		this.tiempo = "0:00";
		this.anioEstreno = 2000;
		this.formato = "NULL";
	}
	public Archivo(String _nombre,String _autor, String _tiempo,int _anio, String _formato){
		this.nombre = _nombre;
		this.autor = _autor;
		this.tiempo = _tiempo;
		this.anioEstreno = _anio;
		this.formato = _formato;
	}
	//GETTERS
	public String getAutor(){
		return this.autor;
	}
	public String getNombre(){
		return this.nombre;
	}
	public String getTiempo(){
		return this.tiempo;
	}
	public int getAnioEstreno(){
		return this.anioEstreno;
	}
	public String getFormato(){
		return this.formato;
		}
	//SETTERS
	public void setAutor(String _Autor){
		this.autor = _Autor;
	}
	public void setNombre(String _nombre){
		this.autor = _nombre;
	}
	public void setTiempo(String _tiempo){
		this.autor = _tiempo;
	}
	public void setFormato(String _formato){
		this.formato = _formato;
	}
	public void setAnioEstreno(int _anioEstreno){
		if (_anioEstreno>2019||_anioEstreno<1900){
			System.out.println("AÑO INVALIDO");
			this.anioEstreno = 0000;
		}else{
			this.anioEstreno = _anioEstreno;
		}
	}
	//Metodos
	public String toString(){
		return "\n\tINFORMACION"+
			   "\n\tNOMBRE: "+this.nombre+
			   "\n\tAUTOR: "+this.autor+
			   "\n\tTIEMPO: "+this.tiempo+
			   "\n\tAÑO ESTRENO: "+this.anioEstreno+
			   "\n\tFormato: "+this.formato;
	}

}