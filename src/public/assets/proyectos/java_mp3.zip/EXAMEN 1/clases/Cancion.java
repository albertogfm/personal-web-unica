package clases;
public class Cancion extends Archivo{
	private String album;
	public Cancion(){
		super();
		this.album = "N/A";
	}
	public Cancion(String _nombre,String _autor, String _tiempo,int _anio,String _formato,String _album){
		super(_nombre,_autor,_tiempo,_anio,_formato);
		this.album = _album;
	}
//SETTERS
	public void setAlbum(String _album){
		this.album = _album;
	}
//GETTERS
	public String getAlbum(){
		return this.album;
		}
//METODOS
	public String toString(){
		return super.toString()+
			   "\n\tAlbum: "+getAlbum();
	}




}