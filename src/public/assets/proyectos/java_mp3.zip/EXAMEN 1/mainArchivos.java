import clases.*;
import java.util.*;
public class mainArchivos{
	//Variables y objetos globales
	private static int num=0;
	private static Cancion songs[] = new Cancion[10];
	private static Video vids[] = new Video[10];
	private static Vector <Archivo> colaArchivos = new Vector <>(5,2);
	//Main
	public static void main(String[] args) {
		//Variables main
		int menu=0, decision=0,indice=0,indfor=0;
		char deciCola;
		Scanner sc = new Scanner(System.in);
		//ITERACION CANCIONES
		
		songs[0] = new Cancion("Stay","Post Malone","5:02",2018,"avi","BeerBONG");
		songs[1] = new Cancion("Congratulations","Post Malone","6:02",2018,"mp3","BeerBONG");
		songs[2] = new Cancion("I know","Rels B","4:15",2017,"mp3","nuevaGeneracion");
		songs[3] = new Cancion("Rosas","La oreja de Van Gogh","3:57",2005,"avi","Rosas");
		songs[4] = new Cancion("Bored","Billie Eilish","3:01",2018,"avi","Bored");
		songs[5] = new Cancion("Elevate","Drake","3:02",2018,"mp3","Scorpion");
		songs[6] = new Cancion("Mob Ties","Drake","3:25",2018,"avi","Scorpion");
		songs[7] = new Cancion("God's Plan","Drake","3:19",2018,"mp3","Scorpion");
		songs[8] = new Cancion("Emotionless","Drake","5:02",2018,"mp3","Scorpion");
		songs[9] = new Cancion("In my feelings","Drake","5:02",2018,"mp3","Scorpion");

		//ITERACION VIDEOS
		
		vids[0] = new Video("Luna (Live)", "Zoe","6:22",2011,"mp4","MTV","ERNESTO");
		vids[1] = new Video("Punto (Live)", "Molotov","6:22",2018,"mp4","MTV","Jonas");
		vids[2] = new Video("Mejor (Live)", "Rels B","8:22",2018,"mov","Itchy","Buco");
		vids[3] = new Video("Euromillon (Live)", "Rels B","7:32",2018,"mp4","MTV","CLARA");
		vids[4] = new Video("Mob Ties (Live)", "Post","3:21",2018,"mp4","MTV","ARISTOTELS");
		vids[5] = new Video("Luna Park (Live)", "Aczino","6:22",2018,"mp4","MTV","PERIFOCLES");
		vids[6] = new Video("GOT S1", "Post","61:51",2012,"mov","HBO","CANTINFLAS");
		vids[7] = new Video("GOT S2", "Post","121:3",2013,"mp4","HBO","CATARINA");
		vids[8] = new Video("El chavo", "Post","20:22",1998,"mov","Televisa","CHESPIRITO");
		vids[9] = new Video("GOT S3", "Post","54:31",2014,"mov","HBO","SOCRATES");
		
		//MENU
		
		while(menu == 0){
			meterLineas(10);
			System.out.println("\n\tESCOGA LO QUE QUIERA HACER");
			System.out.println("\t1.-DESPLEGAR INFO CANCIONES\n\t2.-DESPLEGAR INFO VIDEOS\n\t3.-DESPLEGAR COLA\n\t4.-AGREGAR ARCHIVO A LA COLA\n\t5.-SALIR\t");
			meterLineas(10);	
			decision = sc.nextInt();
			switch (decision){
				case 1:
						for(int i=0;i<10;i++){
							System.out.println("\nCancion: "+(i+1));
							System.out.println(songs[i]);
							meterLineas(6);
						}
						break;
				case 2:
						for(int i=0;i<10;i++){
							System.out.println("\nVideos: "+(i+1));
							System.out.println(vids[i]);
							meterLineas(6);
						}
						break;
				case 3:
						if (colaArchivos.isEmpty() == true){
							System.out.println("\tNo hay ningun archivo en la cola de reproduccion");
						}else{
							System.out.println("Actualmete hay "+colaArchivos.size()+" arcivos en la cola.");
							System.out.println("En la cola estan los siguientes archivos:");
							for (int i=0;i<colaArchivos.size();i++){
								System.out.println("\n\tArchivo "+(i+1)+"\n\t\tNombre: "+colaArchivos.get(i).getNombre()+"\n\t\tFormato: "+colaArchivos.get(i).getFormato()+"\n");
								meterLineas(7);
							}
						}
						break;
				case 4:
						System.out.println("¿Cuantos archivos quiere meter a la cola de reproduccion?");
						indfor = sc.nextInt();

						for (int j=0;j<indfor; j++) {
							
						
							System.out.println("¿Que quieres meter a la cola Musica(M) o Video(V):"+"\t");
							deciCola = sc.next().charAt(0);
								switch (deciCola) {
									case 'M':
									case 'm':
											System.out.println("¿Que numero de Canción quieres meter?");
											indice = sc.nextInt();
											if (indice<0||indice>10){
												System.out.println("Error, inserte un numero valido");
											}else{
												meterColaMusic(songs[indice-1]);
											}
											break;
									case 'V':
									case 'v':
											System.out.println("¿Que numero de Video quieres meter? "+"\t");
											indice = sc.nextInt();
											if (indice<0||indice>10){
												System.out.println("Error, inserte un numero valido");
											}else{
												meterColaVid(vids[indice-1]);
											}
											break;
									default: 
											System.out.println("Error, introduzca un valor valido");
											j--;
											break;
							}
						}
						break;
				case 5:
						menu = 1;
						break;
				default: 
						System.out.println("Error");
						break;
			}
			System.out.println("\n\n");
		}


	}

	public static void meterColaMusic(Archivo _siguiente){
		colaArchivos.add(num, _siguiente);
		num++;
	}
	public static void meterColaVid(Archivo _siguiente){
		colaArchivos.add(num, _siguiente);
		num++;
	}
	public static void meterLineas(int num){
		for(int i=0;i<num;i++){
				System.out.print("------");
			}	
	}






















}