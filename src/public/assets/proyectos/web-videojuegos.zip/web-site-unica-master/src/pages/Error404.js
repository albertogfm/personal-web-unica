const Error404 = () => {
    const view =
        `
        <div><h1>Que no ves que estoy chiquito, ya di error.</h1></div>
        
        `;  
        return view;
};

export default Error404;