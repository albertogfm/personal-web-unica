const Notes = () => {
    const view =
        `
            <div><h3>holi</h3></div>
        `;  
        return view;
};

export default Notes;