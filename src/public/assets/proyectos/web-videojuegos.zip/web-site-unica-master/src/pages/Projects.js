const Projects = () => {
    const view =
        `
        <div> Sigo en construccion porque estoy chiquito :c </div>
        
        `;  
        return view;
};

export default Projects;