const Sony = () => {
    const view =
        `
        <div class="Title"><h1>Noticias del Mundo Gaming</h1></div>
        <div class="news_three-block">
            <h1 id="tlt">Sony lanza trailer de 8 minutos de Death Stranding</h1>
            <span id="sony-photo"></span>
            <div id="-text">
                <p>El 8 de noviembre llegará un juego más, obra de arte más de Hideo Kojima llamado Death Stranding, conocido por sus grandes juegos en Konami, esta vez con su primer título como independiente, Death Stranding.</p>
            </div>
            <div id="n-vid">
                <iframe width="560" height="315" src="https://www.youtube.com/embed/tCI396HyhbQ" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
            </div>
            <div id="-text">
                <p>El juego llega para PlayStation 4, pero recientemente Kojima anunció que llegará a PC a mediados del 2020. </p>
            </div>
        </div>
            
            

        </div>
        
        
        `;  
        return view;
};

export default Sony;