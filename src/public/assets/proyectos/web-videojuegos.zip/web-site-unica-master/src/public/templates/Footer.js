const Footer = () => {
    const view =
        `
            <div>
                <p>GITHUB DE LOS CREADORES DE LA PÁGINA</p>
            </div>
            <div>
                <a href="https://github.com/albertogfm">Alberto Garcia</a>
                <a href="https://github.com/edlayton1">Eduardo Peralta</a>
                <a href="https://github.com/Cristobal115UwU">Cristobal Gutierrez</a>
            </div>
        
        `;  
        return view;
};

export default Footer;