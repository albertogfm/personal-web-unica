Hola, en esta carpeta esta una parte del trabajo de cris que no pudimos agregar porque su node no funcionaba :c
Sorry
